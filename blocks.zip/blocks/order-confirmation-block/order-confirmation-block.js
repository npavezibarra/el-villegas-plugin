console.log('Order Confirmation Block loaded');
// blocks/order-confirmation-block.js
const { registerBlockType } = wp.blocks;
const { __ } = wp.i18n;

registerBlockType('el-villegas/order-confirmation-block', {
    title: __('Order Confirmation Custom Block', 'el-villegas'),
    icon: 'smiley',
    category: 'common', // Change to 'common' to ensure the category is recognized
    edit() {
        return (
            <div className="order-confirmation-custom-block">
                <p>{ __('Custom Order Confirmation Content', 'el-villegas') }</p>
            </div>
        );
    },
    save() {
        return null; // Server-side rendering
    }
});
