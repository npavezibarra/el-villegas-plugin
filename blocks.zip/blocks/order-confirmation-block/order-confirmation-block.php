<?php

function el_villegas_register_custom_block() {
    register_block_type(__DIR__ . '/blocks/order-confirmation-block');
}
add_action('init', 'el_villegas_register_custom_block');

function el_villegas_render_order_confirmation_block($attributes) {
    // Customize your block's output with PHP as needed
    $output = '<div class="order-confirmation-custom-block">';
    $output .= '<h2>Thank you for your purchase!</h2>';
    // Add additional dynamic content here based on order details if needed
    $output .= '</div>';
    return $output;
}
