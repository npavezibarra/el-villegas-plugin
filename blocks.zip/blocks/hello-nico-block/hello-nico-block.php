<?php

// hello-nico-block.php
function el_villegas_register_hello_nico_block() {
    register_block_type(__DIR__ . '/hello-nico-block');
}
add_action('init', 'el_villegas_register_hello_nico_block');
