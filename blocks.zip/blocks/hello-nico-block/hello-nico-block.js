// hello-nico-block.js
const { registerBlockType } = wp.blocks;
const { __ } = wp.i18n;

registerBlockType('el-villegas/hello-nico-block', {
    title: __('Hello Nico Block', 'el-villegas'),
    icon: 'smiley',
    category: 'common',
    edit() {
        return (
            <div className="hello-nico-block">
                <p>{ __('HELLO NICO', 'el-villegas') }</p>
            </div>
        );
    },
    save() {
        return (
            <div className="hello-nico-block">
                <p>{ __('HELLO NICO', 'el-villegas') }</p>
            </div>
        );
    }
});
