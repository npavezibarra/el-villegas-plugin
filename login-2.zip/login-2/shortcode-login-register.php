<?php
/**
 * Shortcode de Login y Registro
 * Uso: [villegas_login_register course_id="123"]
 */

// Función para generar el shortcode
function villegas_login_register_shortcode($atts) {
    // Obtener atributos del shortcode (por ejemplo, el ID del curso)
    $atts = shortcode_atts(
        array(
            'course_id' => null, // ID del curso de LearnDash (opcional)
        ),
        $atts,
        'villegas_login_register'
    );

    // Si el usuario ya está logueado, mostrar un mensaje de bienvenida
    if (is_user_logged_in()) {
        $current_user = wp_get_current_user();
        return '<p>Hola, ' . esc_html($current_user->display_name) . '! <a href="' . esc_url(wp_logout_url(get_permalink())) . '">Cerrar sesión</a></p>';
    }

    // Si el usuario no está logueado, mostrar el formulario de login/registro
    ob_start();
    ?>
    <div id="login-register">
        <div id="form-container">
            <form method="POST" id="login-form">
                <h2 id="form-title">Iniciar Sesión</h2>
                <p id="form-subtitle">Si no tienes cuenta, <a href="#" id="toggle-form">regístrate aquí</a></p>
                
                <input type="text" name="username" placeholder="Nombre de usuario" required id="username">
                <input type="password" name="password" placeholder="Contraseña" required id="password">
                <input type="submit" value="Iniciar Sesión">
                <p id="forgot-pass"><a href="<?php echo esc_url(wp_lostpassword_url()); ?>">Olvidé la contraseña</a></p>
            </form>

            <form method="POST" id="register-form" style="display: none;">
                <h2 id="form-title-register">Registro</h2>
                <p id="form-subtitle-register">Si ya tienes cuenta, <a href="#" id="toggle-form-login">inicia sesión aquí</a></p>
                
                <input type="text" name="first_name" placeholder="Nombre" required id="register-first-name">
                <input type="text" name="last_name" placeholder="Apellido" required id="register-last-name">
                <input type="email" name="email" placeholder="Correo electrónico" required id="register-email">
                <input type="password" name="password" placeholder="Contraseña" required id="register-password">
                <input type="submit" value="Registrarse">
            </form>
        </div>
    </div>
    <?php

    // Aquí se podrían añadir redirecciones o URLs personalizadas basadas en course_id si se necesita

    return ob_get_clean();
}

// Registrar el shortcode
add_shortcode('villegas_login_register', 'villegas_login_register_shortcode');
