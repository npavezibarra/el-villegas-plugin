<?php

// Verificar si el usuario está registrado en el curso
function is_user_enrolled_in_course($user_id, $course_id) {
    return sfwd_lms_has_access($course_id, $user_id);
}

// Obtener la URL de redirección del curso basado en el ID
function get_course_redirect_url($course_id) {
    if (!empty($course_id)) {
        return get_permalink($course_id);
    }
    return home_url(); // Redireccionar a home si no hay curso
}

// Redireccionar al usuario si ya está logueado y tiene acceso al curso
function redirect_logged_in_user($course_id) {
    if (is_user_logged_in()) {
        $user_id = get_current_user_id();

        if (is_user_enrolled_in_course($user_id, $course_id)) {
            // Redirigir al usuario a la página del curso
            wp_redirect(get_course_redirect_url($course_id));
            exit;
        }
    }
}

// Manejar la redirección después de login
function custom_login_redirect($redirect_to, $request, $user) {
    // Verificar si el usuario está logueado y el parámetro de redirección existe
    if (isset($_GET['redirect_to']) && !empty($_GET['redirect_to'])) {
        return esc_url($_GET['redirect_to']);
    }
    return $redirect_to;
}
add_filter('login_redirect', 'custom_login_redirect', 10, 3);

// Validar email y contraseña al registrarse
function validate_registration_data($email, $password) {
    $errors = [];

    if (!is_email($email)) {
        $errors[] = "Por favor ingresa un email válido.";
    }

    if (strlen($password) < 6) {
        $errors[] = "La contraseña debe tener al menos 6 caracteres.";
    }

    return $errors;
}

// Crear un usuario si la validación es exitosa
function create_new_user($email, $password) {
    $userdata = array(
        'user_login' => $email,
        'user_email' => $email,
        'user_pass' => $password,
        'role' => 'subscriber'
    );

    $user_id = wp_insert_user($userdata);

    if (is_wp_error($user_id)) {
        return $user_id->get_error_message();
    }

    return $user_id;
}

